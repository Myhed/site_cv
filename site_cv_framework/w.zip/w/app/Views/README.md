### Répertoire app/Views

Ce répertoire contient vos fichiers de vue. Vous pouvez les classer comme bon vous semble, mais il est habituel de classer les fichiers dans des sous-dossiers correpondant au noms du contrôleur (default/ pour DefaultController). Les *layouts* se trouvent habituellement à la racine de ce répertoire.

Les erreurs personnalisées se trouvent également ici, dans le répertoire w_errors/.